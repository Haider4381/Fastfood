// Small helper for same-origin API calls
async function apiFetch(path, options = {}) {
  const opts = {
    method: options.method || 'GET',
    headers: Object.assign(
      { 'Accept': 'application/json' },
      (options.body ? { 'Content-Type': 'application/json' } : {}),
      options.headers || {}
    ),
    credentials: 'same-origin',
    body: options.body || undefined
  };

  const res = await fetch(path, opts);
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch (_) { data = null; }

  if (!res.ok) {
    const msg = (data && (data.error || data.message)) || res.statusText || 'Request failed';
    throw new Error(msg);
  }
  return data;
}

// Always send user to the correct /public/ root
function goPublicRoot() {
  try {
    // FIX: collapse both slashes and backslashes
    const p = location.pathname.replace(/[/\\]+/g, '/');
    const i = p.indexOf('/public/');
    if (i !== -1) {
      const root = p.slice(0, i + '/public/'.length); // e.g., /fastfoodpos/public/
      location.href = root;
      return;
    }
    location.href = '/fastfoodpos/public/';
  } catch {
    location.href = '/fastfoodpos/public/';
  }
}